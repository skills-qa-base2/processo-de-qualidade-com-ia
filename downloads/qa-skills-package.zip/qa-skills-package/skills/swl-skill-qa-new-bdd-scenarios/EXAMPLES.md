## Cenário direto — Web
**Cenário:** Um QA na "Lojinha Verde" (e-commerce de plantas, web) recebe um critério de aceite simples de busca de produto.
**Input:** "Critério: usuário busca por nome de produto e vê os resultados correspondentes."
**Prompt de exemplo:**
```
/swl-skill-qa-new-bdd-scenarios Critério: usuário busca por nome de produto e vê os resultados correspondentes.
```
**Saída esperada:** A skill deriva as classes do critério — termo com resultado, termo sem resultado, termo vazio — e leva para o `.feature` só o que é crítico no fluxo: o happy path e a busca sem resultado. Caractere especial fica como caso de teste em `swl-skill-qa-new-test-cases` e não vira E2E, porque o risco não justifica manter esse cenário na suíte de aceitação.

## Cenário com ambiguidade — Mobile
**Cenário:** Um QA no app mobile da "TarefaCerta" (gestão de tarefas fictícia) recebe um critério de assinatura de plano com regra de desconto pouco clara.
**Input:** "Critério: usuário assina o plano premium e, se for a segunda assinatura do mesmo usuário, recebe desconto." (sem informar o percentual)
**Prompt de exemplo:**
```
/swl-skill-qa-new-bdd-scenarios Critério: usuário assina o plano premium e, se for a segunda assinatura do mesmo usuário, recebe desconto.
```
**Saída esperada:** A skill gera o cenário happy path da assinatura simples e um Esquema do Cenário pro desconto, mas deixa o percentual como `<percentual_a_confirmar>` nos Exemplos, em vez de inventar um número plausível.

## Cenário de risco real — API
**Cenário:** Na "PagaFácil" (fintech de pagamentos, API), o critério de aceite de estorno descreve três regras diferentes numa frase só (prazo de estorno, taxa de reversão e notificação ao usuário), e o PO pede "um cenário só, pra não ficar grande".
**Input:** critério de aceite denso com 3 regras numa frase, e pedido explícito de resumir em um cenário único.
**Prompt de exemplo:**
```
/swl-skill-qa-new-bdd-scenarios Critério: se o cliente pedir estorno dentro do prazo, o sistema calcula a taxa de reversão aplicável e notifica o usuário do resultado. Quero só um cenário pra isso, não precisa separar em vários.
```
**Saída esperada:** Mesmo com o pedido de simplificar, a skill gera 3 cenários separados — um `Quando` que testa prazo, taxa e notificação ao mesmo tempo não isola qual das três falhou se o teste quebrar. Resumir do jeito pedido deixaria a falha sem indicar qual regra de negócio especificamente parou de funcionar.
